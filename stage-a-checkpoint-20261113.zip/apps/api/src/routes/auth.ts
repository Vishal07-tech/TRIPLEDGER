import { Router } from 'express';

import { getCurrentUser, loginUser, registerUser } from '../controllers/authController.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { requireAuth } from '../middleware/authMiddleware.js';

const router = Router();

router.post('/register', asyncHandler(registerUser));
router.post('/login', asyncHandler(loginUser));
router.get('/me', requireAuth, asyncHandler(getCurrentUser));

export default router;
